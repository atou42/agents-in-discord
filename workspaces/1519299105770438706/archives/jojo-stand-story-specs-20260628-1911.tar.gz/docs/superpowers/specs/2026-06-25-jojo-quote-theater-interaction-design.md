# JoJo Part 5 Quote Theater Interaction Design

Date: 2026-06-25

Status: draft for review

## Goal

Turn the current Golden Wind quote theater from a polished animated carousel into an interactive dynamic manga theater.

The next version should not feel like a gallery with effects. It should feel like each famous line has a small playable trigger. The user should remember the scene by the gesture, not only by the image.

## Current Baseline

The saved baseline is the WebP, no-panel version.

Cohub checkpoint:

`3aac90b5-a0a6-421d-abbc-f664a0d1597b`

Public URL:

`https://s-cff01d0c-3643-40ee-bd8e-5a468d910587-3000.cohub.run/`

Baseline traits:

- 11 scenes.
- English and Japanese text only.
- Local WebP image loading.
- No semi-transparent comic panel boxes.
- Auto carousel with Replay and Pause.
- Tap/click quote replays current scene.

## Product Principle

Each scene gets one primary interaction. The interaction should match the character and the line.

Do not give every scene every gesture. No generic tap-to-sparkle layer. No shared gimmick pasted across characters.

The interaction language should stay simple:

- Tap.
- Drag.
- Hold.
- Multi-tap.
- Scrub.

Each gesture should either deepen the current scene or become a meaningful transition into the next scene.

## Interaction Priority

Build the first interactive pass around three anchor scenes:

- Bucciarati as the gesture-based transition.
- Mista as the rhythmic multi-tap scene.
- Doppio to Diavolo as the time-skip chain.

Giorno remains the opener and should get a cleaner declarative interaction after the transition system is stable.

## Scene Specifications

### Giorno

Role:

Opening declaration.

Primary interaction:

Tap quote.

Behavior:

The first tap on the quote locks `I, Giorno Giovanna` in place. The second beat expands `HAVE A DREAM` with a gold push from the center of the artwork. The scene does not auto-transition from this interaction.

Design intent:

This should establish the theater's emotional contract: famous lines are touchable and can be activated.

Implementation notes:

- Keep the interaction simple.
- No hard flash.
- The gold motion should feel like a vow being lit, not a generic explosion.
- This scene should remain the cleanest onboarding moment.

### Bucciarati

Role:

Primary gesture-based transition.

Primary interaction:

Drag the zipper horizontally across the scene.

Behavior:

The user presses or touches the zipper path and drags across the image. As the drag progresses, the zipper teeth track the finger or pointer, the artwork separates along the zipper path, and the quote splits into two slightly offset layers.

If the drag crosses the threshold, the zipper completes the cut. The scene exits and transitions to the next scene. If the drag does not cross the threshold, everything snaps back.

Design intent:

This is the first moment where the user is not merely replaying an effect. They are performing the famous scene's action.

Threshold:

About 55% horizontal progress on desktop and 48% on mobile.

Success state:

The line `I WILL BETRAY THE BOSS` should feel like it has been cut out of fate.

Failure state:

The zipper line recoils. The scene remains active.

Transition:

On success, use the completed zipper line as the wipe into the next scene. Do not fade out.

### Mista

Role:

Rhythmic multi-tap interaction.

Primary interaction:

Tap or click the scene four times.

Behavior:

Each tap fires one gunshot beat. The first three taps create fast recoil, bullet marks, and short typography jolts. The fourth tap changes the mood: a brief bad-luck pause, a darker frame, and `FOUR IS BAD LUCK` compresses into the foreground.

After the fourth shot, the scene cuts to the next role with a short black-frame or jam-frame transition.

Design intent:

The user should want to complete the count. The fourth tap should feel funny and ominous at the same time.

State:

- Tap count resets when leaving the scene.
- Replay resets tap count.
- Pause freezes current animation but does not clear tap count.

Transition:

Fourth tap triggers next scene after the bad-luck beat.

### Narancia

Role:

Fast movement and resolve.

Primary interaction:

Horizontal swipe.

Behavior:

The airplane trail follows the swipe direction. On release, the plane rushes through the frame. A strong enough swipe transitions to the next scene. A weak swipe only replays a flight pass.

Design intent:

This should be the lightest and fastest gesture in the set.

Transition:

Use speed lines and aircraft motion to pull the scene sideways.

### Fugo

Role:

Pressure and refusal.

Primary interaction:

Hold.

Behavior:

Holding the scene thickens the toxic haze and lowers the contrast at the edges. The quote `I CAN'T GO WITH YOU` feels pressed down, not blown up. Releasing the hold lets the haze thin and restores the frame.

Design intent:

Fugo should not be an action burst. The scene should feel trapped, heavy, and unresolved.

Transition:

No default transition from this interaction. Fugo is an emotional stop.

### Abbacchio

Role:

Memory replay and truth.

Primary interaction:

Horizontal scrub.

Behavior:

Dragging left and right creates a delayed ghost image, like scrubbing through a memory recording. At the correct scrub zone, the clock layer pauses and `THIS IS THE TRUTH` locks into the foreground.

Design intent:

The user should feel like they are finding the truth, not triggering a normal reveal.

Transition:

Optional in later pass. First version can stay in-scene.

### Trish

Role:

Self-awakening.

Primary interaction:

Tap quote.

Behavior:

The image briefly softens and bends. Then it snaps back with `I AM ME!` pushing forward from a soft-material distortion.

Design intent:

The motion should be clean and confident. It should not use explosions, gunfire, or heavy shake.

Transition:

No default transition from this interaction.

### Doppio

Role:

Hidden identity and signal.

Primary interaction:

Repeated tap on quote.

Behavior:

Tapping `Boss... it's me.` produces short signal stutters. After two or three taps, the red silhouette grows clearer, the frame drops a few beats, and the scene transitions into Diavolo.

Design intent:

Doppio should feel like an unstable connection, not a villain reveal immediately.

Transition:

This scene should transition into Diavolo through a signal glitch and time-skip jump.

### Diavolo

Role:

Time deletion.

Primary interaction:

Hold and release.

Behavior:

While holding, animation does not slow down. It loses frames. On release, the scene skips to a new state without showing the in-between motion.

Design intent:

The user should feel that a piece of time was removed.

Transition:

Can transition forward after release if the hold duration crosses threshold. Otherwise it stays in scene.

### Requiem

Role:

Return to zero.

Primary interaction:

Tap quote.

Behavior:

Tapping `THIS IS REQUIEM` reverses or cancels active motion states. Scene effects collapse back toward their starting positions. Controls can briefly become unresponsive, then return.

Design intent:

This should feel like the system itself has been reset.

Transition:

Either return to Giorno or remain on Requiem after the reset. First implementation should remain on Requiem to avoid disorienting users.

## Shared Interaction Rules

The bottom carousel controls remain available. Scene-specific gestures should never make normal navigation impossible.

Pause should pause scene animations, but it should not corrupt in-progress gesture state.

Replay should reset the current scene's local interaction state.

Changing scenes clears scene-local state:

- Mista tap count.
- Bucciarati drag progress.
- Doppio tap count.
- Hold states.
- Scrub progress.

## Visual Rules

Interactions should make the image and quote stronger. They should not add unrelated decoration.

Do not bring back the semi-transparent panel boxes. They were removed because they covered useful artwork and did not communicate anything.

Effects should be tied to scene identity:

- Zipper for Bucciarati.
- Gunshot rhythm for Mista.
- Signal glitch for Doppio.
- Missing frames for Diavolo.
- Toxic haze for Fugo.
- Replay ghost for Abbacchio.
- Soft deformation for Trish.
- Circular reset for Requiem.

## Performance Rules

Keep the WebP pipeline.

Do not reintroduce remote image URLs into runtime scenes.

Preload the current scene and the next three scenes with high priority. Warm the rest during idle time.

Gesture effects should prefer transforms, opacity, clip-path, and CSS variables. Avoid layout-heavy animation.

Do not add large video files for this pass.

## Implementation Shape

Introduce a small scene interaction layer instead of hard-coding all behavior in click handlers.

Each scene can optionally define:

- `interactionType`
- `onPointerDown`
- `onPointerMove`
- `onPointerUp`
- `onQuoteTap`
- `reset`
- `shouldAutoAdvance`

The implementation does not need a framework. It can stay in the current HTML/CSS/JS structure.

## First Implementation Slice

The first build should implement:

- Bucciarati zipper drag-to-transition.
- Mista four-tap gunshot-to-transition.
- Doppio repeated-tap transition into Diavolo.
- Shared state reset when scenes change.

This slice is enough to prove that the theater has become playable.

## Acceptance Criteria

Bucciarati:

- Dragging the zipper visibly tracks pointer movement.
- Dragging past threshold cuts to the next scene.
- Dragging below threshold snaps back.

Mista:

- Each click creates one distinct shot beat.
- Fourth click changes mood and transitions.
- Tap count resets after leaving the scene.

Doppio:

- Repeated quote taps create signal stutter.
- Final tap transitions into Diavolo.

Performance:

- Runtime scene images remain WebP.
- No runtime dependency on remote generated image URLs.
- No PNG scene images requested during normal load.

Visual:

- No semi-transparent panel boxes return.
- Existing carousel controls still work.
- Mobile viewport has no horizontal overflow.

## Open Decisions

The exact sound design is intentionally out of scope for the first pass. Motion should imply sound without requiring audio.

Requiem's reset target remains undecided. First implementation should keep it on Requiem.

Giorno should be implemented after the transition interactions are proven, so the opener can inherit the final timing language.

